# Rich feature hierarchies for accurate object detection and semantic segmentation

Ross Girshick<sup>1</sup> Jeff Donahue<sup>1,2</sup> Trevor Darrell<sup>1,2</sup> Jitendra Malik<sup>1</sup>

<sup>1</sup>UC Berkeley and <sup>2</sup>ICSI

{rbg,jdonahue,trevor,malik}@eecs.berkeley.edu

## Abstract

Object detection performance, as measured on the canonical PASCAL VOC dataset, has plateaued in the last few years. The best-performing methods are complex ensemble systems that typically combine multiple low-level image features with high-level context. In this paper, we propose a simple and scalable detection algorithm that improves mean average precision (mAP) by more than 30% relative to the previous best result on VOC 2012—achieving a mAP of53.3%. Our approach combines two key insights: (1) one can apply high-capacity convolutional neural networks (CNNs) to bottom-up region proposals in order to localize and segment objects and (2) when labeled training data is scarce, supervised pre-trainingfor an auxiliary task, followed by domain-specific fine-tuning, yields a significant performance boost. Since we combine region proposals with CNNs, we call our method R-CNN: Regions with CNN features. We also present experiments that provide insight into what the network learns, revealing a rich hierarchy of image features. Source code for the complete system is available at http://www.cs.berkeley.edu/ <sub>˜</sub>rbg/rcnn.

## 1. Introduction

Features matter. The last decade of progress on various visual recognition tasks has been based considerably on the use of SIFT [26] and HOG [7]. But if we look at performance on the canonical visual recognition task, PASCAL VOC object detection [12], it is generally acknowledged that progress has been slow during 2010-2012, with small gains obtained by building ensemble systems and employing minor variants of successful methods.

SIFT and HOG are blockwise orientation histograms, a representation we could associate roughly with complex cells in V1, the first cortical area in the primate visual pathway. But we also know that recognition occurs several stages downstream, which suggests that there might be hierarchical, multi-stage processes for computing features that are even more informative for visual recognition.

Fukushima’s “neocognitron” [16], a biologicallyinspired hierarchical and shift-invariant model for pattern recognition, was an early attempt at just such a process. The neocognitron, however, lacked a supervised training algorithm. LeCun et al. [23] provided the missing algorithm by showing that stochastic gradient descent, via backpropagation, can train convolutional neural networks (CNNs), a class of models that extend the neocognitron.

![](images/e27434e250ef5b9725668ef318666124d919ed0721ec0344e5621f16fde34c86.jpg)  
Figure 1: Object detection system overview. Our system (1) takes an input image, (2) extracts around 2000 bottom-up region proposals, (3) computes features for each proposal using a large convolutional neural network (CNN), and then (4) classifies each region using class-specific linear SVMs. R-CNN achieves a mean average precision (mAP) of 53.7% on PASCAL VOC 2010. For comparison, [32] reports 35.1% mAP using the same region proposals, but with a spatial pyramid and bag-of-visual-words approach. The popular deformable part models perform at 33.4%.

CNNs saw heavy use in the 1990s (e.g., [24]), but then fell out of fashion, particularly in computer vision, with the rise of support vector machines. In 2012, Krizhevsky et al. [22] rekindled interest in CNNs by showing substantially higher image classification accuracy on the ImageNet Large Scale Visual Recognition Challenge (ILSVRC) [9, 10]. Their success resulted from training a large CNN on 1.2 million labeled images, together with a few twists on Le-Cun’s CNN (e.g., max(x, 0) rectifying non-linearities and “dropout” regularization).

The significance of the ImageNet result was vigorously debated during the ILSVRC 2012 workshop. The central issue can be distilled to the following: To what extent do the CNN classification results on ImageNet generalize to object detection results on the PASCAL VOC Challenge?

We answer this question decisively by bridging the chasm between image classification and object detection. This paper is the first to show that a CNN can lead to dramatically higher object detection performance on PASCAL VOC as compared to systems based on simpler HOG-like features.<sup>1</sup> Achieving this result required solving two problems: localizing objects with a deep network and training a high-capacity model with only a small quantity of annotated detection data.

Unlike image classification, detection requires localizing (likely many) objects within an image. One approach frames localization as a regression problem. However, work from Szegedy et al. [31], concurrent with our own, indicates that this strategy may not fare well in practice (they report a mAP of 30.5% on VOC 2007 compared to the 58.5% achieved by our method). An alternative is to build a sliding-window detector. CNNs have been used in this way for at least two decades, typically on constrained object categories, such as faces [28, 33] and pedestrians [29]. In order to maintain high spatial resolution, these CNNs typically only have two convolutional and pooling layers. We also considered adopting a sliding-window approach. However, units high up in our network, which has five convolutional layers, have very large receptive fields (195 × 195 pixels) and strides (32×32 pixels) in the input image, which makes precise localization within the sliding-window paradigm an open technical challenge.

Instead, we solve the CNN localization problem by operating within the “recognition using regions” paradigm, as argued for by Gu et al. in [18]. At test-time, our method generates around 2000 category-independent region proposals for the input image, extracts a fixed-length feature vector from each proposal using a CNN, and then classifies each region with category-specific linear SVMs. We use a simple technique (affine image warping) to compute a fixed-size CNN input from each region proposal, regardless of the region’s shape. Figure 1 presents an overview of our method and highlights some of our results. Since our system combines region proposals with CNNs, we dub the method R-CNN: Regions with CNN features.

A second challenge faced in detection is that labeled data is scarce and the amount currently available is insufficient for training a large CNN. The conventional solution to this problem is to use unsupervised pre-training, followed by supervised fine-tuning (e.g., [29]). The second major contribution of this paper is to show that supervised pretraining on a large auxiliary dataset (ILSVRC), followed by domain-specific fine-tuning on a small dataset (PASCAL), is an effective paradigm for learning high-capacity CNNs when data is scarce. In our experiments, fine-tuning for detection improves mAP performance by 8 percentage points. After fine-tuning, our system achieves a mAP of 54% on VOC 2010 compared to 33% for the highly-tuned, HOGbased deformable part model (DPM) [14, 17].

Our system is also quite efficient. The only class-specific computations are a reasonably small matrix-vector product and greedy non-maximum suppression. This computational property follows from features that are shared across all categories and that are also two orders of magnitude lowerdimensional than previously used region features (cf. [32]).

One advantage of HOG-like features is their simplicity: it’s easier to understand the information they carry (although [34] shows that our intuition can fail us). Can we gain insight into the representation learned by the CNN? Perhaps the densely connected layers, with more than 54 million parameters, are the key? They are not. We “lobotomized” the CNN and found that a surprisingly large proportion, 94%, of its parameters can be removed with only a moderate drop in detection accuracy. Instead, by probing units in the network we see that the convolutional layers learn a diverse set of rich features (Figure 3).

Understanding the failure modes of our approach is also critical for improving it, and so we report results from the detection analysis tool of Hoiem et al. [20]. As an immediate consequence of this analysis, we demonstrate that a simple bounding box regression method significantly reduces mislocalizations, which are the dominant error mode.

Before developing technical details, we note that because R-CNN operates on regions it is natural to extend it to the task of semantic segmentation. With minor modifications, we also achieve state-of-the-art results on the PAS-CAL VOC segmentation task, with an average segmentation accuracy of 47.9% on the VOC 2011 test set.

## 2. Object detection with R-CNN

Our object detection system consists of three modules. The first generates category-independent region proposals. These proposals define the set of candidate detections available to our detector. The second module is a large convolutional neural network that extracts a fixed-length feature vector from each region. The third module is a set of classspecific linear SVMs. In this section, we present our design decisions for each module, describe their test-time usage, detail how their parameters are learned, and show results on PASCAL VOC 2010-12.

## 2.1. Module design

Region proposals. A variety of recent papers offer methods for generating category-independent region proposals. Examples include: objectness [1], selective search [32], category-independent object proposals [11], constrained parametric min-cuts (CPMC) [5], multi-scale combinatorial grouping [3], and Cires¸an et al. [6], who detect mitotic cells by applying a CNN to regularly-spaced square crops, which are a special case of region proposals. While R-CNN is agnostic to the particular region proposal method, we use selective search to enable a controlled comparison with prior detection work (e.g., [32, 35]).

![](images/5f2a2d054e45509e37ab7a4ef062de5e87a17db3f35e439e6d07049128693351.jpg)  
Figure 2: Warped training samples from VOC 2007 train.

Feature extraction. We extract a 4096-dimensional feature vector from each region proposal using the Caffe [21] implementation of the CNN described by Krizhevsky et al. [22]. Features are computed by forward propagating a mean-subtracted 227 × 227 RGB image through five convolutional layers and two fully connected layers. We refer readers to [21, 22] for more network architecture details.

In order to compute features for a region proposal, we must first convert the image data in that region into a form that is compatible with the CNN (its architecture requires inputs of a fixed 227 × 227 pixel size). Of the many possible transformations of our arbitrary-shaped regions, we opt for the simplest. Regardless of the size or aspect ratio of the candidate region, we warp all pixels in a tight bounding box around it to the required size. Prior to warping, we dilate the tight bounding box so that at the warped size there are exactly p pixels of warped image context around the original box (we use p = 16). Figure 2 shows a random sampling of warped training regions. The supplementary material discusses alternatives to warping.

## 2.2. Test-time detection

At test time, we run selective search on the test image to extract around 2000 region proposals (we use selective search’s “fast mode” in all experiments). We warp each proposal and forward propagate it through the CNN in order to read off features from the desired layer. Then, for each class, we score each extracted feature vector using the SVM trained for that class. Given all scored regions in an image, we apply a greedy non-maximum suppression (for each class independently) that rejects a region if it has an intersection-over-union (IoU) overlap with a higher scoring selected region larger than a learned threshold.

Run-time analysis. Two properties make detection efficient. First, all CNN parameters are shared across all categories. Second, the feature vectors computed by the CNN are low-dimensional when compared to other common approaches, such as spatial pyramids with bag-of-visual-word encodings. The features used in the UVA detection system [32], for example, are two orders of magnitude larger than ours (360k vs. 4k-dimensional).

The result of such sharing is that the time spent computing region proposals and features (13s/image on a GPU or 53s/image on a CPU) is amortized over all classes. The only class-specific computations are dot products between features and SVM weights and non-maximum suppression. In practice, all dot products for an image are batched into a single matrix-matrix product. The feature matrix is typically 2000×4096 and the SVM weight matrix is 4096×N, where N is the number of classes.

This analysis shows that R-CNN can scale to thousands of object classes without resorting to approximate techniques, such as hashing. Even if there were 100k classes, the resulting matrix multiplication takes only 10 seconds on a modern multi-core CPU. This efficiency is not merely the result of using region proposals and shared features. The UVA system, due to its high-dimensional features, would be two orders of magnitude slower while requiring 134GB of memory just to store 100k linear predictors, compared to just 1.5GB for our lower-dimensional features.

It is also interesting to contrast R-CNN with the recent work from Dean et al. on scalable detection using DPMs and hashing [8]. They report a mAP of around 16% on VOC 2007 at a run-time of 5 minutes per image when introducing 10k distractor classes. With our approach, 10k detectors can run in about a minute on a CPU, and because no approximations are made mAP would remain at 59% (Section 3.2).

## 2.3. Training

Supervised pre-training. We discriminatively pre-trained the CNN on a large auxiliary dataset (ILSVRC 2012) with image-level annotations (i.e., no bounding box labels). Pretraining was performed using the open source Caffe CNN library [21]. In brief, our CNN nearly matches the performance of Krizhevsky et al. [22], obtaining a top-1 error rate 2.2 percentage points higher on the ILSVRC 2012 validation set. This discrepancy is due to simplifications in the training process.

Domain-specific fine-tuning. To adapt our CNN to the new task (detection) and the new domain (warped VOC windows), we continue stochastic gradient descent (SGD) training of the CNN parameters using only warped region proposals from VOC. Aside from replacing the CNN’s ImageNet-specific 1000-way classification layer with a randomly initialized 21-way classification layer (for the 20 VOC classes plus background), the CNN architecture is unchanged. We treat all region proposals with ≥ 0.5 IoU overlap with a ground-truth box as positives for that box’s class and the rest as negatives. We start SGD at a learning rate of 0.001 (1/10th of the initial pre-training rate), which allows fine-tuning to make progress while not clobbering the initialization. In each SGD iteration, we uniformly sample 32 positive windows (over all classes) and 96 background windows to construct a mini-batch of size 128. We bias the sampling towards positive windows because they are extremely rare compared to background.

<table><tr><td>VOC 2010 test</td><td>aero</td><td>bike</td><td>bird</td><td>boat</td><td>bottle</td><td>bus</td><td>car</td><td>cat</td><td>chair</td><td>cow</td><td>table</td><td>dog</td><td>horse</td><td>mbike</td><td>person</td><td>plant</td><td>sheep</td><td>sofa</td><td>train</td><td>tv</td><td>mAP</td></tr><tr><td>DPM v5 [17]†</td><td>49.2</td><td>53.8</td><td>13.1</td><td>15.3</td><td>35.5</td><td>53.4</td><td>49.7</td><td>27.0</td><td>17.2</td><td>28.8</td><td>14.7</td><td>17.8</td><td>46.4</td><td>51.2</td><td>47.7</td><td>10.8</td><td>34.2</td><td>20.7</td><td>43.8</td><td>38.3</td><td>33.4</td></tr><tr><td>UVA [32]</td><td>56.2</td><td>42.4</td><td>15.3</td><td>12.6</td><td>21.8</td><td>49.3</td><td>36.8</td><td>46.1</td><td>12.9</td><td>32.1</td><td>30.0</td><td>36.5</td><td>43.5</td><td>52.9</td><td>32.9</td><td>15.3</td><td>41.1</td><td>31.8</td><td>47.0</td><td>44.8</td><td>35.1</td></tr><tr><td>Regionlets [35]</td><td>65.0</td><td>48.9</td><td>25.9</td><td>24.6</td><td>24.5</td><td>56.1</td><td>54.5</td><td>51.2</td><td>17.0</td><td>28.9</td><td>30.2</td><td>35.8</td><td>40.2</td><td>55.7</td><td>43.5</td><td>14.3</td><td>43.9</td><td>32.6</td><td>54.0</td><td>45.9</td><td>39.7</td></tr><tr><td>SegDPM [15]†</td><td>61.4</td><td>53.4</td><td>25.6</td><td>25.2</td><td>35.5</td><td>51.7</td><td>50.6</td><td>50.8</td><td>19.3</td><td>33.8</td><td>26.8</td><td>40.4</td><td>48.3</td><td>54.4</td><td>47.1</td><td>14.8</td><td>38.7</td><td>35.0</td><td>52.8</td><td>43.1</td><td>40.4</td></tr><tr><td>R-CNN</td><td>67.1</td><td>64.1</td><td>46.7</td><td>32.0</td><td>30.5</td><td>56.4</td><td>57.2</td><td>65.9</td><td>27.0</td><td>47.3</td><td>40.9</td><td>66.6</td><td>57.8</td><td>65.9</td><td>53.6</td><td>26.7</td><td>56.5</td><td>38.1</td><td>52.8</td><td>50.2</td><td>50.2</td></tr><tr><td>R-CNN BB</td><td>71.8</td><td>65.8</td><td>53.0</td><td>36.8</td><td>35.9</td><td>59.7</td><td>60.0</td><td>69.9</td><td>27.9</td><td>50.6</td><td>41.4</td><td>70.0</td><td>62.0</td><td>69.0</td><td>58.1</td><td>29.5</td><td>59.4</td><td>39.3</td><td>61.2</td><td>52.4</td><td>53.7</td></tr></table>

Table 1: Detection average precision (%) on VOC 2010 test. R-CNN is most directly comparable to UVA and Regionlets since all methods use selective search region proposals. Bounding box regression (BB) is described in Section 3.4. At publication time, SegDPM was the top-performer on the PASCAL VOC leaderboard. <sup>†</sup>DPM and SegDPM use context rescoring not used by the other methods.

Object category classifiers. Consider training a binary classifier to detect cars. It’s clear that an image region tightly enclosing a car should be a positive example. Similarly, it’s clear that a background region, which has nothing to do with cars, should be a negative example. Less clear is how to label a region that partially overlaps a car. We resolve this issue with an IoU overlap threshold, below which regions are defined as negatives. The overlap threshold, 0.3, was selected by a grid search over $\{ 0 , 0 . 1 , \ldots , 0 . 5 \}$ on a validation set. We found that selecting this threshold carefully is important. Setting it to 0.5, as in [32], decreased mAP by 5 points. Similarly, setting it to 0 decreased mAP by 4 points. Positive examples are defined simply to be the ground-truth bounding boxes for each class.

Once features are extracted and training labels are applied, we optimize one linear SVM per class. Since the training data is too large to fit in memory, we adopt the standard hard negative mining method [14, 30]. Hard negative mining converges quickly and in practice mAP stops increasing after only a single pass over all images.

In supplementary material we discuss why the positive and negative examples are defined differently in fine-tuning versus SVM training. We also discuss why it’s necessary to train detection classifiers rather than simply use outputs from the final layer $\left( \mathrm { f c } _ { 8 } \right)$ of the fine-tuned CNN.

## 2.4. Results on PASCAL VOC 2010-12

Following the PASCAL VOC best practices [12], we validated all design decisions and hyperparameters on the VOC 2007 dataset (Section 3.2). For final results on the VOC 2010-12 datasets, we fine-tuned the CNN on VOC 2012 train and optimized our detection SVMs on VOC 2012 trainval. We submitted test results to the evaluation server only once for each of the two major algorithm variants (with and without bounding box regression).

Table 1 shows complete results on VOC 2010. We compare our method against four strong baselines, including SegDPM [15], which combines DPM detectors with the output of a semantic segmentation system [4] and uses additional inter-detector context and image-classifier rescoring. The most germane comparison is to the UVA system from Uijlings et al. [32], since our systems use the same region proposal algorithm. To classify regions, their method builds a four-level spatial pyramid and populates it with densely sampled SIFT, Extended OpponentSIFT, and RGB-SIFT descriptors, each vector quantized with 4000-word codebooks. Classification is performed with a histogram intersection kernel SVM. Compared to their multi-feature, non-linear kernel SVM approach, we achieve a large improvement in mAP, from 35.1% to 53.7% mAP, while also being much faster (Section 2.2). Our method achieves similar performance (53.3% mAP) on VOC 2011/12 test.

## 3. Visualization, ablation, and modes of error

## 3.1. Visualizing learned features

First-layer filters can be visualized directly and are easy to understand [22]. They capture oriented edges and opponent colors. Understanding the subsequent layers is more challenging. Zeiler and Fergus present a visually attractive deconvolutional approach in [36]. We propose a simple (and complementary) non-parametric method that directly shows what the network learned.

The idea is to single out a particular unit (feature) in the network and use it as if it were an object detector in its own right. That is, we compute the unit’s activations on a large set of held-out region proposals (about 10 million), sort the proposals from highest to lowest activation, perform nonmaximum suppression, and then display the top-scoring regions. Our method lets the selected unit “speak for itself” by showing exactly which inputs it fires on. We avoid averaging in order to see different visual modes and gain insight into the invariances computed by the unit.

We visualize units from layer $\mathrm { p o o l } _ { 5 } ,$ which is the maxpooled output of the network’s fifth and final convolutional layer. The $\mathrm { p o o l _ { 5 } }$ feature map is $6 \times 6 \times 2 5 6 ~ = ~ 9 2 1 6 .$ dimensional. Ignoring boundary effects, each pool unit has a receptive field of $1 9 5 \times 1 9 5$ pixels in the original $2 2 7 \times 2 2 7$ pixel input. A central pool unit has a nearly global view, while one near the edge has a smaller, clipped support.

Each row in Figure 3 displays the top 16 activations for a $\mathrm { p o o l _ { 5 } }$ unit from a CNN that we fine-tuned on VOC 2007 trainval. Six of the 256 functionally unique units are visualized (the supplementary material includes more). These units were selected to show a representative sample of what the network learns. In the second row, we see a unit that fires on dog faces and dot arrays. The unit corresponding to the third row is a red blob detector. There are also detectors for human faces and more abstract patterns such as text and triangular structures with windows. The network appears to learn a representation that combines a small number of class-tuned features together with a distributed representation of shape, texture, color, and material properties. The subsequent fully connected layer $\mathrm { f c } _ { 6 }$ has the ability to model a large set of compositions of these rich features.

![](images/4cd4765c73d24e72a86e2db342a16fa56c5da07cb1e78b3b610de52fd9abf96f.jpg)

Figure 3: Top regions for six pool units. Receptive fields and activation values are drawn in white. Some units are aligned to concepts, such as people (row 1) or text (4). Other units capture texture and material properties, such as dot arrays (2) and specular reflections (6).

<table><tr><td>VOC 2007 test</td><td>aero</td><td>bike</td><td>bird</td><td>boat</td><td>bottle</td><td>bus</td><td>car</td><td>cat</td><td>chair</td><td>cow</td><td>table</td><td>dog</td><td>horse</td><td>mbike</td><td>person</td><td>plant</td><td>sheep</td><td>sofa</td><td>train</td><td>tv</td><td>mAP</td></tr><tr><td>R-CNN  $pool_{5}$ </td><td>51.8</td><td>60.2</td><td>36.4</td><td>27.8</td><td>23.2</td><td>52.8</td><td>60.6</td><td>49.2</td><td>18.3</td><td>47.8</td><td>44.3</td><td>40.8</td><td>56.6</td><td>58.7</td><td>42.4</td><td>23.4</td><td>46.1</td><td>36.7</td><td>51.3</td><td>55.7</td><td>44.2</td></tr><tr><td>R-CNN  $fc_{6}$ </td><td>59.3</td><td>61.8</td><td>43.1</td><td>34.0</td><td>25.1</td><td>53.1</td><td>60.6</td><td>52.8</td><td>21.7</td><td>47.8</td><td>42.7</td><td>47.8</td><td>52.5</td><td>58.5</td><td>44.6</td><td>25.6</td><td>48.3</td><td>34.0</td><td>53.1</td><td>58.0</td><td>46.2</td></tr><tr><td>R-CNN  $fc_{7}$ </td><td>57.6</td><td>57.9</td><td>38.5</td><td>31.8</td><td>23.7</td><td>51.2</td><td>58.9</td><td>51.4</td><td>20.0</td><td>50.5</td><td>40.9</td><td>46.0</td><td>51.6</td><td>55.9</td><td>43.3</td><td>23.3</td><td>48.1</td><td>35.3</td><td>51.0</td><td>57.4</td><td>44.7</td></tr><tr><td>R-CNN FT  $pool_{5}$ </td><td>58.2</td><td>63.3</td><td>37.9</td><td>27.6</td><td>26.1</td><td>54.1</td><td>66.9</td><td>51.4</td><td>26.7</td><td>55.5</td><td>43.4</td><td>43.1</td><td>57.7</td><td>59.0</td><td>45.8</td><td>28.1</td><td>50.8</td><td>40.6</td><td>53.1</td><td>56.4</td><td>47.3</td></tr><tr><td>R-CNN FT  $fc_{6}$ </td><td>63.5</td><td>66.0</td><td>47.9</td><td>37.7</td><td>29.9</td><td>62.5</td><td>70.2</td><td>60.2</td><td>32.0</td><td>57.9</td><td>47.0</td><td>53.5</td><td>60.1</td><td>64.2</td><td>52.2</td><td>31.3</td><td>55.0</td><td>50.0</td><td>57.7</td><td>63.0</td><td>53.1</td></tr><tr><td>R-CNN FT  $fc_{7}$ </td><td>64.2</td><td>69.7</td><td>50.0</td><td>41.9</td><td>32.0</td><td>62.6</td><td>71.0</td><td>60.7</td><td>32.7</td><td>58.5</td><td>46.5</td><td>56.1</td><td>60.6</td><td>66.8</td><td>54.2</td><td>31.5</td><td>52.8</td><td>48.9</td><td>57.9</td><td>64.7</td><td>54.2</td></tr><tr><td>R-CNN FT  $fc_{7}$  BB</td><td>68.1</td><td>72.8</td><td>56.8</td><td>43.0</td><td>36.8</td><td>66.3</td><td>74.2</td><td>67.6</td><td>34.4</td><td>63.5</td><td>54.5</td><td>61.2</td><td>69.1</td><td>68.6</td><td>58.7</td><td>33.4</td><td>62.9</td><td>51.1</td><td>62.5</td><td>64.8</td><td>58.5</td></tr><tr><td>DPM v5 [17]</td><td>33.2</td><td>60.3</td><td>10.2</td><td>16.1</td><td>27.3</td><td>54.3</td><td>58.2</td><td>23.0</td><td>20.0</td><td>24.1</td><td>26.7</td><td>12.7</td><td>58.1</td><td>48.2</td><td>43.2</td><td>12.0</td><td>21.1</td><td>36.1</td><td>46.0</td><td>43.5</td><td>33.7</td></tr><tr><td>DPM ST [25]</td><td>23.8</td><td>58.2</td><td>10.5</td><td>8.5</td><td>27.1</td><td>50.4</td><td>52.0</td><td>7.3</td><td>19.2</td><td>22.8</td><td>18.1</td><td>8.0</td><td>55.9</td><td>44.8</td><td>32.4</td><td>13.3</td><td>15.9</td><td>22.8</td><td>46.2</td><td>44.9</td><td>29.1</td></tr><tr><td>DPM HSC [27]</td><td>32.2</td><td>58.3</td><td>11.5</td><td>16.3</td><td>30.6</td><td>49.9</td><td>54.8</td><td>23.5</td><td>21.5</td><td>27.7</td><td>34.0</td><td>13.7</td><td>58.1</td><td>51.6</td><td>39.9</td><td>12.4</td><td>23.5</td><td>34.4</td><td>47.4</td><td>45.2</td><td>34.3</td></tr></table>

Table 2: Detection average precision (%) on VOC 2007 test. Rows 1-3 show R-CNN performance without fine-tuning. Rows 4-6 show results for the CNN pre-trained on ILSVRC 2012 and then fine-tuned (FT) on VOC 2007 trainval. Row 7 includes a simple bounding box regression (BB) stage that reduces localization errors (Section 3.4). Rows 8-10 present DPM methods as a strong baseline. The first uses only HOG, while the next two use different feature learning approaches to augment or replace HOG.

## 3.2. Ablation studies

Performance layer-by-layer, without fine-tuning. To understand which layers are critical for detection performance, we analyzed results on the VOC 2007 dataset for each of the CNN’s last three layers. Layer $\mathrm { p o o l _ { 5 } }$ was briefly described in Section 3.1. The final two layers are summarized below.

Layer $\mathrm { f c } _ { 6 }$ is fully connected to pool . To compute features, it multiplies a $4 0 9 6 \times 9 2 1 6$ weight matrix by the pool feature map (reshaped as a 9216-dimensional vector) and then adds a vector of biases. This intermediate vector is component-wise half-wave rectified $( x \gets \operatorname* { m a x } ( 0 , x ) )$ .

Layer $\mathrm { f c } _ { 7 }$ is the final layer of the network. It is implemented by multiplying the features computed by $\mathrm { f c } _ { 6 }$ by a 4096 × 4096 weight matrix, and similarly adding a vector of biases and applying half-wave rectification.

We start by looking at results from the CNN without fine-tuning on PASCAL, i.e. all CNN parameters were pretrained on ILSVRC 2012 only. Analyzing performance layer-by-layer (Table 2 rows 1-3) reveals that features from $\mathrm { f c } _ { 7 }$ generalize worse than features from $\mathrm { f c } _ { 6 }$ . This means that 29%, or about 16.8 million, of the CNN’s parameters can be removed without degrading mAP. More surprising is that removing both $\mathrm { f c } _ { 7 }$ and $\mathrm { f c } _ { 6 }$ produces quite good results even though $\mathrm { p o o l _ { 5 } }$ features are computed using only 6% of the CNN’s parameters. Much of the CNN’s representational power comes from its convolutional layers, rather than from the much larger densely connected layers. This finding suggests potential utility in computing a dense feature map, in the sense of HOG, of an arbitrary-sized image by using only the convolutional layers of the CNN. This representation would enable experimentation with sliding-window detectors, including DPM, on top of $\mathrm { p o o l _ { 5 } }$ features.

Performance layer-by-layer, with fine-tuning. We now look at results from our CNN after having fine-tuned its parameters on VOC 2007 trainval. The improvement is striking (Table 2 rows 4-6): fine-tuning increases mAP by $8 . 0$ percentage points to 54.2%. The boost from fine-tuning is much larger for $\mathrm { f c } _ { 6 }$ and $\mathrm { f c } _ { 7 }$ than for $\mathrm { \ p o o l _ { 5 } } .$ , which suggests that the $\mathrm { p o o l _ { 5 } }$ features learned from ImageNet are general and that most of the improvement is gained from learning domain-specific non-linear classifiers on top of them.

Comparison to recent feature learning methods. Relatively few feature learning methods have been tried on PAS-CAL VOC detection. We look at two recent approaches that build on deformable part models. For reference, we also include results for the standard HOG-based DPM [17].

The first DPM feature learning method, DPM ST [25], augments HOG features with histograms of “sketch token” probabilities. Intuitively, a sketch token is a tight distribution of contours passing through the center of an image patch. Sketch token probabilities are computed at each pixel by a random forest that was trained to classify $3 5 \times 3 5$ pixel patches into one of 150 sketch tokens or background.

The second method, DPM HSC [27], replaces HOG with histograms of sparse codes (HSC). To compute an HSC, sparse code activations are solved for at each pixel using a learned dictionary of $1 0 0 ~ 7 \times 7 ~ \AA$ pixel (grayscale) atoms. The resulting activations are rectified in three ways (full and both half-waves), spatially pooled, unit $\ell _ { 2 }$ normalized, and then power transformed $( x  \mathrm { s i g n } ( x ) | x | ^ { \alpha } )$ ).

All R-CNN variants strongly outperform the three DPM baselines (Table 2 rows 8-10), including the two that use feature learning. Compared to the latest version of DPM, which uses only HOG features, our mAP is more than 20 percentage points higher: 54.2% vs. 33.7%—a 61% relative improvement. The combination of HOG and sketch tokens yields 2.5 mAP points over HOG alone, while HSC improves over HOG by 4 mAP points (when compared internally to their private DPM baselines—both use nonpublic implementations of DPM that underperform the open source version [17]). These methods achieve mAPs of 29.1% and 34.3%, respectively.

## 3.3. Detection error analysis

We applied the excellent detection analysis tool from Hoiem et al. [20] in order to reveal our method’s error modes, understand how fine-tuning changes them, and to see how our error types compare with DPM. A full summary of the analysis tool is beyond the scope of this paper and we encourage readers to consult [20] to understand some finer details (such as “normalized $\mathbf { A P } ^ { * } )$ ). Since the analysis is best absorbed in the context of the associated plots, we present the discussion within the captions of Figure 4 and Figure 5.

![](images/8145693fc47c216c66dd0174463e590efcf0eec6b57ae3f35b3d31effb09d5e7.jpg)

![](images/687135c190865d043be269b88062a4c89f68ff72cfc5822454798b047c4b75a3.jpg)

![](images/59c536a168349c857fae24650d80e0e632bcf5e8aa5c78485d153ca29013734a.jpg)

![](images/fc9b314142f2723b740362bd5402101dfb4b6128c3c3bb2d0a3333edd0e85ab3.jpg)

![](images/ae71921a4d8660a3f024bc55469507c55ec37de56cbd5c33b78edacd26230b85.jpg)

![](images/e25449a1e3feb207c0d9e2a69c96fcae970855ce5d8cfa31719ab4b306de9ea8.jpg)  
Figure 4: Distribution of top-ranked false positive (FP) types. Each plot shows the evolving distribution of FP types as more FPs are considered in order of decreasing score. Each FP is categorized into 1 of 4 types: Loc—poor localization (a detection with an IoU overlap with the correct class between 0.1 and 0.5, or a duplicate); Sim—confusion with a similar category; Oth—confusion with a dissimilar object category; $\mathrm { B G \mathrm { - } a \ F P }$ that fired on background. Compared with DPM (see [20]), significantly more of our errors result from poor localization, rather than confusion with background or other object classes, indicating that the CNN features are much more discriminative than HOG. Loose localization likely results from our use of bottom-up region proposals and the positional invariance learned from pre-training the CNN for whole-image classification. Column three shows how our simple bounding box regression method fixes many localization errors.

## 3.4. Bounding box regression

Based on the error analysis, we implemented a simple method to reduce localization errors. Inspired by the bounding box regression employed in DPM [14], we train a linear regression model to predict a new detection window given the $\mathrm { p o o l _ { 5 } }$ features for a selective search region proposal. Full details are given in the supplementary material. Results in Table 1, Table 2, and Figure 4 show that this simple approach fixes a large number of mislocalized detections, boosting mAP by 3 to 4 points.

## 4. Semantic segmentation

Region classification is a standard technique for semantic segmentation, allowing us to easily apply R-CNN to the

![](images/435f61488ca28745db40495d0f32f6d68677108393541cd3f857318d3815958f.jpg)

![](images/6d9a2e6af70f4ff2982422f091e1c742d5c91b4e1b71a135f587d0762e7394f3.jpg)

![](images/f0f094e85710a8e50d6b63f8b4012819807b89c0dfa3f46bcb27b2b6d759e832.jpg)

![](images/e60f0033c81eda57f86d87234301d23f94e5e318e5dd26605c53b3ef5c82b78e.jpg)  
Figure 5: Sensitivity to object characteristics. Each plot shows the mean (over classes) normalized AP (see [20]) for the highest and lowest performing subsets within six different object characteristics (occlusion, truncation, bounding box area, aspect ratio, viewpoint, part visibility). We show plots for our method (R-CNN) with and without fine-tuning (FT) and bounding box regression (BB) as well as for DPM voc-release5. Overall, fine-tuning does not reduce sensitivity (the difference between max and min), but does substantially improve both the highest and lowest performing subsets for nearly all characteristics. This indicates that fine-tuning does more than simply improve the lowest performing subsets for aspect ratio and bounding box area, as one might conjecture based on how we warp network inputs. Instead, fine-tuning improves robustness for all characteristics including occlusion, truncation, viewpoint, and part visibility.

PASCAL VOC segmentation challenge. To facilitate a direct comparison with the current leading semantic segmentation system (called $\mathrm { O _ { 2 } P }$ for “second-order pooling”) [4], we work within their open source framework. $\mathrm { O _ { 2 } P }$ uses CPMC to generate 150 region proposals per image and then predicts the quality of each region, for each class, using support vector regression (SVR). The high performance of their approach is due to the quality of the CPMC regions and the powerful second-order pooling of multiple feature types (enriched variants of SIFT and LBP). We also note that Farabet et al. [13] recently demonstrated good results on several dense scene labeling datasets (not including PAS-CAL) using a CNN as a multi-scale per-pixel classifier.

We follow [2, 4] and extend the PASCAL segmentation training set to include the extra annotations made available by Hariharan et al. [19]. Design decisions and hyperparameters were cross-validated on the VOC 2011 validation set. Final test results were evaluated only once.

CNN features for segmentation. We evaluate three strategies for computing features on CPMC regions, all of which begin by warping the rectangular window around the region to $2 2 7 \times 2 2 7$ . The first strategy (full) ignores the region’s shape and computes CNN features directly on the warped window, exactly as we did for detection. However, these features ignore the non-rectangular shape of the region. Two regions might have very similar bounding boxes while having very little overlap. Therefore, the second strategy (fg) computes CNN features only on a region’s foreground mask. We replace the background with the mean input so that background regions are zero after mean subtraction. The third strategy $( f u l l { + } f g )$ simply concatenates thefull andfg features; our experiments validate their complementarity.

Results on VOC 2011. Table 3 shows a summary of our results on the VOC 2011 validation set compared with $\mathrm { O _ { 2 } P } .$ (See supplementary material for complete per-category results.) Within each feature computation strategy, layer $\mathrm { f c } _ { 6 }$ always outperforms $\mathrm { f c } _ { 7 }$ and the following discussion refers to the $\mathrm { f c } _ { 6 }$ features. The $f g$ strategy slightly outperforms full, indicating that the masked region shape provides a stronger signal, matching our intuition. However, full+fg achieves an average accuracy of 47.9%, our best result by a margin of 4.2% (also modestly outperforming $\mathrm { O _ { 2 } P ) }$ , indicating that the context provided by thefull features is highly informative even given the $f g$ features. Notably, training the 20 SVRs on our $f u l l { + } f g$ features takes an hour on a single core, compared to 10+ hours for training on $\mathrm { O _ { 2 } P }$ features.

<table><tr><td></td><td colspan="2">full R-CNN</td><td colspan="2">fg R-CNN</td><td colspan="2">full+fg R-CNN</td></tr><tr><td> $O_{2}P$  [4]</td><td> $fc_{6}$ </td><td> $fc_{7}$ </td><td> $fc_{6}$ </td><td> $fc_{7}$ </td><td> $fc_{6}$ </td><td> $fc_{7}$ </td></tr><tr><td>46.4</td><td>43.0</td><td>42.5</td><td>43.7</td><td>42.1</td><td>47.9</td><td>45.8</td></tr></table>

Table 3: Segmentation mean accuracy (%) on VOC 2011 validation. Column 1 presents $\mathrm { O _ { 2 } P ; 2 - 7 }$ use our CNN pre-trained on ILSVRC 2012.

In Table 4 we present results on the VOC 2011 test set, comparing our best-performing method, $\mathrm { f c } _ { 6 } ~ ( f u l l + f g )$ against two strong baselines. Our method achieves the highest segmentation accuracy for 11 out of 21 categories, and the highest overall segmentation accuracy of 47.9%, averaged across categories (but likely ties with the $\mathrm { O _ { 2 } P }$ result under any reasonable margin of error). Still better performance could likely be achieved by fine-tuning.

## 5. Conclusion

In recent years, object detection performance had stagnated. The best performing systems were complex ensembles combining multiple low-level image features with high-level context from object detectors and scene classifiers. This paper presents a simple and scalable object detection algorithm that gives a 30% relative improvement over the best previous results on PASCAL VOC 2012.

We achieved this performance through two insights. The first is to apply high-capacity convolutional neural networks to bottom-up region proposals in order to localize and segment objects. The second is a paradigm for training large CNNs when labeled training data is scarce. We show that it is highly effective to pre-train the network— with supervision—for a auxiliary task with abundant data (image classification) and then to fine-tune the network for the target task where data is scarce (detection). We conjecture that the “supervised pre-training/domain-specific finetuning” paradigm will be highly effective for a variety of data-scarce vision problems.

<table><tr><td>VOC 2011 test</td><td>bg</td><td>aero</td><td>bike</td><td>bird</td><td>boat</td><td>bottle</td><td>bus</td><td>car</td><td>cat</td><td>chair</td><td>cow</td><td>table</td><td>dog</td><td>horse</td><td>mbike</td><td>person</td><td>plant</td><td>sheep</td><td>sofa</td><td>train</td><td>tv</td><td>mean</td></tr><tr><td>R&amp;P [2]</td><td>83.4</td><td>46.8</td><td>18.9</td><td>36.6</td><td>31.2</td><td>42.7</td><td>57.3</td><td>47.4</td><td>44.1</td><td>8.1</td><td>39.4</td><td>36.1</td><td>36.3</td><td>49.5</td><td>48.3</td><td>50.7</td><td>26.3</td><td>47.2</td><td>22.1</td><td>42.0</td><td>43.2</td><td>40.8</td></tr><tr><td> $O_{2}P$  [4]</td><td>85.4</td><td>69.7</td><td>22.3</td><td>45.2</td><td>44.4</td><td>46.9</td><td>66.7</td><td>57.8</td><td>56.2</td><td>13.5</td><td>46.1</td><td>32.3</td><td>41.2</td><td>59.1</td><td>55.3</td><td>51.0</td><td>36.2</td><td>50.4</td><td>27.8</td><td>46.9</td><td>44.6</td><td>47.6</td></tr><tr><td>ours (full+fg R-CNN  $fc_6$ )</td><td>84.2</td><td>66.9</td><td>23.7</td><td>58.3</td><td>37.4</td><td>55.4</td><td>73.3</td><td>58.7</td><td>56.5</td><td>9.7</td><td>45.5</td><td>29.5</td><td>49.3</td><td>40.1</td><td>57.8</td><td>53.9</td><td>33.8</td><td>60.7</td><td>22.7</td><td>47.1</td><td>41.3</td><td>47.9</td></tr></table>

Table 4: Segmentation accuracy (%) on VOC 2011 test. We compare against two strong baselines: the “Regions and Parts” (R&P) method of [2] and the second-order pooling (O<sub>2</sub>P) method of [4]. Without any fine-tuning, our CNN achieves top segmentation performance, outperforming R&P and roughly matching O<sub>2</sub>P.

We conclude by noting that it is significant that we achieved these results by using a combination of classical tools from computer vision and deep learning (bottomup region proposals and convolutional neural networks). Rather than opposing lines of scientific inquiry, the two are natural and inevitable partners.

Acknowledgments. This research was supported in part by DARPA Mind’s Eye and MSEE programs, by NSF awards IIS-0905647, IIS-1134072, and IIS-1212798, MURI N000014-10-1-0933, and by support from Toyota. The GPUs used in this research were generously donated by the NVIDIA Corporation.

## References

[1] B. Alexe, T. Deselaers, and V. Ferrari. Measuring the objectness of image windows. TPAMI, 2012.

[2] P. Arbelaez, B. Hariharan, C. Gu, S. Gupta, L. Bourdev, and J. Malik.´ Semantic segmentation using regions and parts. In CVPR, 2012.

[3] P. Arbelaez, J. Pont-Tuset, J. Barron, F. Marques, and J. Malik. Mul-´ tiscale combinatorial grouping. In CVPR, 2014.

[4] J. Carreira, R. Caseiro, J. Batista, and C. Sminchisescu. Semantic segmentation with second-order pooling. In ECCV, 2012.

[5] J. Carreira and C. Sminchisescu. CPMC: Automatic object segmentation using constrained parametric min-cuts. TPAMI, 2012.

[6] D. Cires¸an, A. Giusti, L. Gambardella, and J. Schmidhuber. Mitosis detection in breast cancer histology images with deep neural networks. In MICCAI, 2013.

[7] N. Dalal and B. Triggs. Histograms of oriented gradients for human detection. In CVPR, 2005.

[8] T. Dean, M. A. Ruzon, M. Segal, J. Shlens, S. Vijayanarasimhan, and J. Yagnik. Fast, accurate detection of 100,000 object classes on a single machine. In CVPR, 2013.

[9] J. Deng, A. Berg, S. Satheesh, H. Su, A. Khosla, and L. Fei-Fei. ImageNet Large Scale Visual Recognition Competition 2012 (ILSVRC2012). http://www.image-net.org/ challenges/LSVRC/2012/.

[10] J. Deng, W. Dong, R. Socher, L.-J. Li, K. Li, and L. Fei-Fei. ImageNet: A large-scale hierarchical image database. In CVPR, 2009.

[11] I. Endres and D. Hoiem. Category independent object proposals. In ECCV, 2010.

[12] M. Everingham, L. Van Gool, C. K. I. Williams, J. Winn, and A. Zisserman. The PASCAL Visual Object Classes (VOC) Challenge. IJCV, 2010.

[13] C. Farabet, C. Couprie, L. Najman, and Y. LeCun. Learning hierarchical features for scene labeling. TPAMI, 2013.

[14] P. Felzenszwalb, R. Girshick, D. McAllester, and D. Ramanan. Object detection with discriminatively trained part based models. TPAMI, 2010.

[15] S. Fidler, R. Mottaghi, A. Yuille, and R. Urtasun. Bottom-up segmentation for top-down detection. In CVPR, 2013.

[16] K. Fukushima. Neocognitron: A self-organizing neural network model for a mechanism of pattern recognition unaffected by shift in position. Biological cybernetics, 36(4):193–202, 1980.

[17] R. Girshick, P. Felzenszwalb, and D. McAllester. Discriminatively trained deformable part models, release 5. http://www.cs. berkeley.edu/<sub>˜</sub>rbg/latent-v5/.

[18] C. Gu, J. J. Lim, P. Arbelaez, and J. Malik. Recognition using re-´ gions. In CVPR, 2009.

[19] B. Hariharan, P. Arbelaez, L. Bourdev, S. Maji, and J. Malik. Seman-´ tic contours from inverse detectors. In ICCV, 2011.

[20] D. Hoiem, Y. Chodpathumwan, and Q. Dai. Diagnosing error in object detectors. In ECCV. 2012.

[21] Y. Jia. Caffe: An open source convolutional architecture for fast feature embedding. http://caffe.berkeleyvision.org/, 2013.

[22] A. Krizhevsky, I. Sutskever, and G. Hinton. ImageNet classification with deep convolutional neural networks. In NIPS, 2012.

[23] Y. LeCun, B. Boser, J. Denker, D. Henderson, R. Howard, W. Hubbard, and L. Jackel. Backpropagation applied to handwritten zip code recognition. Neural Comp., 1989.

[24] Y. LeCun, L. Bottou, Y. Bengio, and P. Haffner. Gradient-based learning applied to document recognition. Proc. ofthe IEEE, 1998.

[25] J. J. Lim, C. L. Zitnick, and P. Dollar. Sketch tokens: A learned´ mid-level representation for contour and object detection. In CVPR, 2013.

[26] D. Lowe. Distinctive image features from scale-invariant keypoints. IJCV, 2004.

[27] X. Ren and D. Ramanan. Histograms of sparse codes for object detection. In CVPR, 2013.

[28] H. A. Rowley, S. Baluja, and T. Kanade. Neural network-based face detection. TPAMI, 1998.

[29] P. Sermanet, K. Kavukcuoglu, S. Chintala, and Y. LeCun. Pedestrian detection with unsupervised multi-stage feature learning. In CVPR, 2013.

[30] K. Sung and T. Poggio. Example-based learning for view-based human face detection. Technical Report A.I. Memo No. 1521, Massachussets Institute of Technology, 1994.

[31] C. Szegedy, A. Toshev, and D. Erhan. Deep neural networks for object detection. In NIPS, 2013.

[32] J. Uijlings, K. van de Sande, T. Gevers, and A. Smeulders. Selective search for object recognition. IJCV, 2013.

[33] R. Vaillant, C. Monrocq, and Y. LeCun. Original approach for the localisation of objects in images. IEE Proc on Vision, Image, and Signal Processing, 1994.

[34] C. Vondrick, A. Khosla, T. Malisiewicz, and A. Torralba. HOGgles: visualizing object detection features. ICCV, 2013.

[35] X. Wang, M. Yang, S. Zhu, and Y. Lin. Regionlets for generic object detection. In ICCV, 2013.

[36] M. Zeiler, G. Taylor, and R. Fergus. Adaptive deconvolutional networks for mid and high level feature learning. In CVPR, 2011.